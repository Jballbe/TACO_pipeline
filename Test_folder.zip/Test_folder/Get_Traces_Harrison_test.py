#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 22 10:24:31 2025

@author: julienballbe
"""

import numpy as np
def get_trace_Harisson(original_cell_file_folder,cell_id,sweep_list,cell_sweep_table):
    
    time_trace_list = []
    potential_trace_list = []
    current_trace_list = []
    stim_start_time_list = []
    stim_end_time_list= []
    
    current_step_values = np.fromfile(f'{original_cell_file_folder}Istep_{cell_id}.bin',dtype='<f')
    potential_traces = np.fromfile(f'{original_cell_file_folder}Vstep_{cell_id}.bin',dtype='<f')
    
    potential_trace_split = int(len(potential_traces)/len(current_step_values))

    stim_start_time = float(cell_sweep_table.loc[cell_sweep_table['Cell_id']==cell_id,'Stimulus_start_time_s'].values[0])
    stim_end_time = float(cell_sweep_table.loc[cell_sweep_table['Cell_id']==cell_id,'Stimulus_end_time_s'].values[0])
    
    for sweep_id in sweep_list:
    
        CC, protocol, trace_nb = sweep_id.split("_")
        first_index = int(trace_nb)*potential_trace_split
        last_index = (int(trace_nb)+1)*potential_trace_split
        potential_trace =  potential_traces[first_index:last_index]


    
        sampling_frequency = 20000 #from Harisson et al 
        sweep_duration = len(potential_trace)/sampling_frequency
        time_trace=np.arange(0,sweep_duration,(1/sampling_frequency))
    
        stim_amp = float(current_step_values[int(trace_nb)])
    
        current_trace = np.zeros(len(time_trace))
        stim_start_index=np.argmin(abs(time_trace-stim_start_time))
        stim_end_index = np.argmin(abs(time_trace- stim_end_time))
        current_trace[stim_start_index:stim_end_index]+=stim_amp
        
        time_trace_list.append(time_trace)
        potential_trace_list.append(potential_trace)
        current_trace_list.append(current_trace)
        stim_start_time_list.append(stim_start_time)
        stim_end_time_list.append(stim_end_time)
    
    return time_trace_list, potential_trace_list, current_trace_list, stim_start_time_list, stim_end_time_list