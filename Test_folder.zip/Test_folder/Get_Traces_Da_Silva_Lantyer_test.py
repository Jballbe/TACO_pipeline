#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 22 10:27:22 2025

@author: julienballbe
"""

import scipy
import pandas as pd
import numpy as np
def get_traces_Lantyer(original_cell_file_folder,cell_id,sweep_list,cell_sweep_table):
    
    time_trace_list = []
    potential_trace_list = []
    current_trace_list = []
    
    
    #Get file name
    file_name = cell_sweep_table.loc[cell_sweep_table['Cell_id'] == cell_id,
                                     'Original_file'].unique()[0]

    #open File
    current_file = scipy.io.loadmat(str(
        str(original_cell_file_folder)+str(file_name)))
    current_unique_cell_id = cell_id[-1]
    
    for sweep_id in sweep_list:
        #Get sweep from file 
        experiment,current_Protocol,current_sweep = sweep_id.split("_")
        current_id = str('Trace_'+current_unique_cell_id+'_' +
                         current_Protocol+'_'+str(current_sweep))
        #Get traces
        current_stim_trace = pd.DataFrame(
            current_file[str(current_id+'_1')], columns=['Time_s', 'Input_current_pA'])
        current_stim_trace.loc[:, 'Input_current_pA'] *= 1e12 #To pA
    
        current_membrane_trace = pd.DataFrame(
            current_file[str(current_id+'_2')], columns=['Time_s', 'Membrane_potential_mV'])
        current_membrane_trace.loc[:, 'Membrane_potential_mV'] *= 1e3 #to mV
    
        time_trace = np.array(current_membrane_trace.loc[:, 'Time_s'])
        potential_trace = np.array(
            current_membrane_trace.loc[:, 'Membrane_potential_mV'])
        
        current_trace = np.array(current_stim_trace.loc[:, 'Input_current_pA'])
        
        time_trace_list.append(time_trace)
        potential_trace_list.append(potential_trace)
        current_trace_list.append(current_trace)
        
    return time_trace_list , potential_trace_list, current_trace_list